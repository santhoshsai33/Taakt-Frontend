import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Card, Form, Button, Container, Row, Col, Spinner } from 'react-bootstrap';
import { FiEye, FiEyeOff } from 'react-icons/fi';
import { loginUser } from '../../api/authApi';

const Login = () => {
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();
    const {
        register,
        handleSubmit,
        formState: { errors, isSubmitting },
    } = useForm({
        mode: 'onTouched',
        reValidateMode: 'onChange',
        defaultValues: {
            email: '',
            password: '',
        },
    });

    const handleLogin = async (formData) => {
        try {
            const payload = {
                email: formData.email.trim().toLowerCase(),
                password: formData.password,
            };
            const response = await loginUser(payload);
            const { token } = response.data.data;

            localStorage.setItem('authToken', token);

            toast.success(response.data.message || 'Login successful');
            navigate('/dashboard');
        } catch (error) {
            const message = error.response?.data?.message || 'Login failed. Please check your email and password.';
            toast.error(message);
        }
    };

    return (
        <div className="login-wrapper">
            <Container>
                <Row className="justify-content-center align-items-center vh-100">
                    <Col md={5} lg={4}>
                        <Card className="login-card p-4">
                            <Card.Body>
                                <div className="text-center mb-4">
                                    <img src="/img/logo.jpg" alt="Taakt Logo" style={{ height: '70px', width: 'auto', objectFit: 'contain' }} />
                                </div>

                                <h5 className="fw-bold mb-4 text-center">Welcome Back!</h5>

                                <Form onSubmit={handleSubmit(handleLogin)}>
                                    <Form.Group className="mb-4">
                                        <Form.Label className="fw-semibold text-secondary" style={{ fontSize: '0.9rem' }}>
                                            Email <span className="required-mark">*</span>
                                        </Form.Label>
                                        <div className="login-field">
                                            <Form.Control
                                                type="email"
                                                placeholder="Enter your email"
                                                className={`login-input ${errors.email ? 'has-error' : ''}`}
                                                aria-invalid={errors.email ? 'true' : 'false'}
                                                {...register('email', {
                                                    required: 'Email is required',
                                                    validate: (value) => {
                                                        const email = value.trim();

                                                        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                                                            return 'Enter a valid email address';
                                                        }

                                                        return true;
                                                    },
                                                })}
                                            />
                                        </div>
                                        {errors.email && <div className="login-error-text">{errors.email.message}</div>}
                                    </Form.Group>

                                    <Form.Group className="mb-4">
                                        <div className="d-flex justify-content-between">
                                            <Form.Label className="fw-semibold text-secondary" style={{ fontSize: '0.9rem' }}>
                                                Password <span className="required-mark">*</span>
                                            </Form.Label>

                                        </div>
                                        <div className="login-field">
                                            <Form.Control
                                                type={showPassword ? 'text' : 'password'}
                                                placeholder="Enter password"
                                                className={`login-input with-toggle ${errors.password ? 'has-error' : ''}`}
                                                aria-invalid={errors.password ? 'true' : 'false'}
                                                {...register('password', {
                                                    required: 'Password is required',
                                                    minLength: {
                                                        value: 6,
                                                        message: 'Password must be at least 6 characters',
                                                    },
                                                })}
                                            />
                                            <button
                                                type="button"
                                                className="password-toggle-btn"
                                                onClick={() => setShowPassword((current) => !current)}
                                                aria-label={showPassword ? 'Hide password' : 'Show password'}
                                            >
                                                {showPassword ? <FiEyeOff /> : <FiEye />}
                                            </button>
                                        </div>
                                        {errors.password && <div className="login-error-text">{errors.password.message}</div>}
                                    </Form.Group>
                                    <a href="#" className="text-decoration-none text-primary text-end" style={{ fontSize: '0.85rem' }}>Forgot password?</a>

                                    <Button variant="primary" type="submit" className="w-100 py-3 rounded-3 fw-bold login-btn mt-2" disabled={isSubmitting}>
                                        {isSubmitting && <Spinner animation="border" size="sm" className="me-2" />}
                                        {isSubmitting ? 'Logging in...' : 'Login'}
                                    </Button>
                                </Form>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default Login;
