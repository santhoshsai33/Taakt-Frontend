import { useEffect, useState } from 'react';
import { Table, Button, Modal, Spinner, Form } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import PageTitle from '../../components/PageTitle/PageTitle';
import StatusBadge from '../../components/StatusBadge/StatusBadge';
import { getShipmentList } from '../../api/shipmentsApi';
import { FaPlus, FaEye, FaEdit, FaTrash, FaChevronLeft, FaChevronRight } from 'react-icons/fa';

const defaultPagination = {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 5,
    hasNextPage: false,
    hasPrevPage: false,
};

const formatEnumLabel = (value = '') => {
    return value.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, (letter) => letter.toUpperCase());
};

const Shipments = () => {
    const navigate = useNavigate();

    const [shipments, setShipments] = useState([]);
    const [pagination, setPagination] = useState(defaultPagination);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(5);
    const [isLoading, setIsLoading] = useState(true);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [shipmentToDelete, setShipmentToDelete] = useState(null);

    useEffect(() => {
        const fetchShipments = async () => {
            setIsLoading(true);

            try {
                const response = await getShipmentList({ page, pageSize });
                const data = response.data?.data;

                setShipments(data?.items || []);
                setPagination(data?.pagination || defaultPagination);
            } catch (error) {
                const message = error.response?.data?.message || 'Unable to load shipment list.';
                toast.error(message);
            } finally {
                setIsLoading(false);
            }
        };

        fetchShipments();
    }, [page, pageSize]);

    const handleAddClick = () => {
        navigate('/shipments/add');
    };

    const handlePageSizeChange = (event) => {
        setPage(1);
        setPageSize(Number(event.target.value));
    };

    const handleDeleteClick = (shipment) => {
        setShipmentToDelete(shipment);
        setShowDeleteModal(true);
    };

    const confirmDelete = () => {
        setShowDeleteModal(false);
        setShipmentToDelete(null);
    };

    const cancelDelete = () => {
        setShowDeleteModal(false);
        setShipmentToDelete(null);
    };

    const startItem = pagination.totalItems === 0 ? 0 : ((pagination.currentPage - 1) * pageSize) + 1;
    const endItem = Math.min(pagination.currentPage * pageSize, pagination.totalItems);

    return (
        <div>
            {/* Page Header */}
            <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
                <PageTitle title="Shipment Management" />
                <Button
                    variant="primary"
                    onClick={handleAddClick}
                    className="d-flex align-items-center gap-2 shadow-sm custom-btn rounded-3 px-3 py-2 fw-bold"
                    style={{ whiteSpace: 'nowrap' }}
                >
                    <FaPlus /> <span className="d-none d-sm-inline">Add New Shipment</span><span className="d-sm-none">Add</span>
                </Button>
            </div>

            <div className="custom-table-container">
                <Table responsive hover className="mb-0 align-middle">
                    <thead className="bg-light">
                        <tr>
                            <th className="py-3 px-4 rounded-start">Shipment ID</th>
                            <th className="py-3">Reference ID</th>
                            <th className="py-3">Trip Type</th>
                            <th className="py-3">From</th>
                            <th className="py-3">Current Loc</th>
                            <th className="py-3">To</th>
                            <th className="py-3">Status</th>
                            <th className="py-3 px-4 rounded-end text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading && (
                            <tr>
                                <td colSpan={8} className="text-center py-5">
                                    <Spinner animation="border" size="sm" className="me-2" />
                                    Loading shipments...
                                </td>
                            </tr>
                        )}
                        {!isLoading && shipments.length === 0 && (
                            <tr>
                                <td colSpan={8} className="text-center text-muted py-5">No shipments found.</td>
                            </tr>
                        )}
                        {!isLoading && shipments.map((shipment) => (
                            <tr key={shipment._id}>
                                <td className="py-3 px-3 fw-bold text-primary" style={{ whiteSpace: 'nowrap' }}>{shipment.orderId}</td>
                                <td className="py-3 text-secondary fw-medium" style={{ whiteSpace: 'nowrap' }}>{shipment.referenceId}</td>
                                <td className="py-3 text-secondary fw-medium" style={{ whiteSpace: 'nowrap' }}>{formatEnumLabel(shipment.tripType)}</td>
                                <td className="py-3 fw-bold text-dark" style={{ whiteSpace: 'nowrap' }}>{shipment.fromLocation}</td>
                                <td className="py-3 text-primary fw-semibold" style={{ whiteSpace: 'nowrap' }}>{shipment.currentLocation}</td>
                                <td className="py-3 fw-bold text-dark" style={{ whiteSpace: 'nowrap' }}>{shipment.toLocation}</td>
                                <td className="py-3" style={{ whiteSpace: 'nowrap' }}><StatusBadge status={shipment.currentStatus} /></td>
                                <td className="py-3 px-3">
                                    <div className="d-flex justify-content-center gap-2">
                                        <button
                                            className="tbl-action-btn tbl-action-view"
                                            title="View"
                                            onClick={() => navigate(`/shipments/view/${shipment.orderId}`)}
                                        ><FaEye /></button>
                                        <button
                                            className="tbl-action-btn tbl-action-edit"
                                            title="Edit"
                                        ><FaEdit /></button>
                                        <button
                                            className="tbl-action-btn tbl-action-delete"
                                            title="Delete"
                                            onClick={() => handleDeleteClick(shipment)}
                                        ><FaTrash /></button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>

                {/* Pagination Bar */}
                <div className="shp-pagination">
                    <div className="shp-pagination-info">
                        Showing <strong>{startItem}–{endItem}</strong> of <strong>{pagination.totalItems}</strong>
                    </div>

                    <div className="shp-pagination-controls">
                        <div className="shp-rows-select">
                            <span className="shp-rows-label">Rows</span>
                            <Form.Select
                                className="shp-select"
                                value={pageSize}
                                onChange={handlePageSizeChange}
                                disabled={isLoading}
                            >
                                <option value={5}>5</option>
                                <option value={10}>10</option>
                                <option value={15}>15</option>
                            </Form.Select>
                        </div>

                        <div className="shp-page-btns">
                            <button
                                className="shp-nav-btn"
                                disabled={!pagination.hasPrevPage || isLoading}
                                onClick={() => setPage(p => Math.max(p - 1, 1))}
                            >
                                <FaChevronLeft size={11} /> <span className="d-none d-sm-inline">Prev</span>
                            </button>

                            <span className="shp-page-indicator">
                                {pagination.currentPage} / {pagination.totalPages}
                            </span>

                            <button
                                className="shp-nav-btn"
                                disabled={!pagination.hasNextPage || isLoading}
                                onClick={() => setPage(p => p + 1)}
                            >
                                <span className="d-none d-sm-inline">Next</span> <FaChevronRight size={11} />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <Modal show={showDeleteModal} onHide={cancelDelete} centered>
                <Modal.Header closeButton className="border-0 pb-0">
                    <Modal.Title className="fw-bold text-danger">Confirm Delete</Modal.Title>
                </Modal.Header>
                <Modal.Body className="py-4 text-center">
                    <FaTrash className="text-danger mb-3" style={{ fontSize: '3rem', opacity: 0.2 }} />
                    <h5 className="mb-2">Are you sure?</h5>
                    <p className="text-muted mb-0">
                        Do you really want to delete shipment {shipmentToDelete?.orderId || ''}? This process cannot be undone.
                    </p>
                </Modal.Body>
                <Modal.Footer className="border-0 pt-0 d-flex justify-content-center gap-2 pb-4">
                    <Button variant="light" className="px-4 fw-bold" onClick={cancelDelete}>
                        No, Cancel
                    </Button>
                    <Button variant="danger" className="px-4 fw-bold" onClick={confirmDelete}>
                        Yes, Delete
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default Shipments;
