import axiosClient from './axiosClient';

export const loginUser = (payload) => {
  return axiosClient.post('/auth/login', payload);
};
