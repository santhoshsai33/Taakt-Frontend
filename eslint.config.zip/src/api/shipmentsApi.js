import axiosClient from './axiosClient';

export const createShipment = (payload) => {
  return axiosClient.post('/shipments', payload);
};

export const getShipmentDashboard = () => {
  return axiosClient.get('/shipments/dashboard');
};

export const getShipmentList = ({ page = 1, pageSize = 5 } = {}) => {
  return axiosClient.get('/shipments/list', {
    params: {
      page,
      pageSize,
    },
  });
};

export const getShipmentDropdownOptions = () => {
  return axiosClient.get('/shipments/dropdown');
};

export const getShipmentDetails = (shipmentId) => {
  return axiosClient.get(`/shipments/${shipmentId}`);
};

export const updateShipment = (shipmentId, payload) => {
  return axiosClient.put(`/shipments/update/${shipmentId}`, payload);
};
